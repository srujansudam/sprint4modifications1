package com.cg.ibs.rm.service;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import com.cg.ibs.rm.bean.AccountBean;
import com.cg.ibs.rm.dao.AccountDaoImpl;
import com.cg.ibs.rm.exception.IBSExceptions;

public class AccountServiceImpl implements AccountService{
	private AccountDaoImpl accountdao = new AccountDaoImpl();
	@Override
	public Set<AccountBean> getAccountsOfUci(BigInteger uci) throws IBSExceptions {
		return new HashSet<>(accountdao.getAccounts(uci));
	}
	
}
