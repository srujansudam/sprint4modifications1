package com.cg.ibs.rm.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import org.apache.log4j.Logger;
import com.cg.ibs.rm.bean.AccountBean;
import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.CustomerBean;
import com.cg.ibs.rm.bean.ServiceProvider;
import com.cg.ibs.rm.bean.ServiceProviderId;
import com.cg.ibs.rm.exception.ExceptionMessages;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.util.JpaUtil;

public class AutoPaymentDAOImpl implements AutoPaymentDAO {
	EntityManager manager = JpaUtil.getEntityManger();
	private static final Logger LOGGER = Logger.getLogger(AutoPaymentDAOImpl.class);

	@Override
	public Set<AutoPayment> getAutopaymentDetails(BigInteger uci) throws IBSExceptions {
		LOGGER.info("entered getAutopaymentDetails in AutoPaymentDAOImpl");
		TypedQuery<AutoPayment> query = manager.createQuery(
				"SELECT a FROM AutoPayment a  WHERE a.serviceProviderId.uci = ?1",
				AutoPayment.class);
		query.setParameter(1, uci);
		List<AutoPayment> list = query.getResultList();
		if(!list.isEmpty()) {
		return new HashSet<>(list);
		} else {
			throw new IBSExceptions("No autopayments added.");
		}
	}

	@Override
	public boolean copyDetails(BigInteger uci, AutoPayment autoPayment) throws IBSExceptions {
		LOGGER.info("entered copyDetails in AutoPaymentDAOImpl");
		boolean result = false;
		if (null == manager.find(AutoPayment.class, autoPayment.getServiceProviderId())) {
			CustomerBean customerBean = manager.find(CustomerBean.class, uci);
			customerBean.getAutoPayments().add(autoPayment);
			manager.persist(autoPayment);// why not customer bean
			result = true;
		} else {
			throw new IBSExceptions(ExceptionMessages.AUTOPAYMENT_ALREADY_ADDED);
		}
		return result;
	}

	@Override
	public boolean deleteDetails(BigInteger uci, BigInteger spi) throws IBSExceptions {
		boolean result = false;
		LOGGER.info("entered deleteDetails in AutoPaymentDAOImpl");
		AutoPayment autoPayment = manager.find(AutoPayment.class, new ServiceProviderId(spi, uci));
		if (null != autoPayment) {
			manager.remove(autoPayment);
		} else {
			throw new IBSExceptions(ExceptionMessages.AUTOPAYMENT_DOESNT_EXIST);
		}
		return result;
	}

	@Override
	public Set<ServiceProvider> showServiceProviderList() {
		LOGGER.info("entered showServiceProviderList in AutoPaymentDAOImpl");
		TypedQuery<ServiceProvider> query = manager.createQuery("SELECT a FROM ServiceProvider a",
				ServiceProvider.class);
		return new HashSet<>(query.getResultList());
	}

	@Override
	public BigDecimal getCurrentBalance(BigInteger accountNumber) throws IBSExceptions {
		BigDecimal bigDecimal = null;
		LOGGER.info("entered getCurrentBalance in AutoPaymentDAOImpl");
		AccountBean account = manager.find(AccountBean.class, accountNumber);
		if (null != account) {
			bigDecimal = account.getBalance();
		}
		return bigDecimal;
	}

	@Override
	public boolean setCurrentBalance(BigDecimal currentBalance, BigInteger accountNumber) {
		LOGGER.info("entered setCurrentBalance in AutoPaymentDAOImpl");
		boolean result = false;
		AccountBean account = manager.find(AccountBean.class, accountNumber);
		account.setBalance(currentBalance);
		if (manager.merge(account) != null) {
			result = true;
		}
		return result;
	}
}