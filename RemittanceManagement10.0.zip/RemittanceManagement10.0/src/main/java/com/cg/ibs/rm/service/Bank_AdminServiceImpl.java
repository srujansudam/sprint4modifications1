package com.cg.ibs.rm.service;

import java.math.BigInteger;
import java.util.Set;

import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.dao.Bank_AdminDAO;
import com.cg.ibs.rm.dao.Bank_AdminDAOImpl;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.util.JpaUtil;

public class Bank_AdminServiceImpl implements Bank_AdminService {
	private Bank_AdminDAO bankRepresentativeDAO = new Bank_AdminDAOImpl();
	private static Logger logger = Logger.getLogger(Bank_AdminServiceImpl.class);

	@Override
	public Set<BigInteger> showRequests() {
		logger.info("entering into showRequests method of Bank_AdminServiceImpl class");
		return bankRepresentativeDAO.getRequests();

	}

	@Override
	public Set<CreditCard> showUnapprovedCreditCards(BigInteger uci) {
		logger.info("entering into showUnapprovedCreditCards method of BankRepresentativeServiceImpl class");
		return bankRepresentativeDAO.getCreditCardDetails(uci);

	}

	@Override
	public Set<Beneficiary> showUnapprovedBeneficiaries(BigInteger uci) {
		logger.info("entering into showUnapprovedBeneficiaries method of BankRepresentativeServiceImpl class");
		return bankRepresentativeDAO.getBeneficiaryDetails(uci);
	}

	@Override
	public boolean saveCreditCardDetails(CreditCard card) throws IBSExceptions {
		logger.info("Entering into checkedCreditCardDetails method of Bank Admin in case of approved cards");
		boolean result = false;
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		if (bankRepresentativeDAO.checkedCreditCardDetails(card)) {
			result = true;
		}
		entityTransaction.commit();
		return result;
	}

	@Override
	public boolean saveBeneficiaryDetails(Beneficiary beneficiary) throws IBSExceptions {
		logger.info("Entering into checkedBeneficiaryDetails method of Bank Admin in case of approved beneficiaries");

		boolean result = false;
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		if (bankRepresentativeDAO.checkedBeneficiaryDetails(beneficiary)) {
			result = true;
		}
		entityTransaction.commit();
		return result;
	}

	@Override
	public boolean disapproveCreditCard(CreditCard card) throws IBSExceptions {
		logger.info("Entering into checkedCreditCardDetails method of Bank Admin in case of disapproved cards");
		boolean result = false;
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		if (bankRepresentativeDAO.decliningCreditCardDetails(card)) {
			result = true;
		}
		entityTransaction.commit();
		return result;
	}

	@Override
	public boolean disapproveBenficiary(Beneficiary beneficiary) throws IBSExceptions {
		logger.info(
				"Entering into checkedBeneficiaryDetails method of Bank Admin in case of disapproved beneficiaries");
		boolean result = false;
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		if (bankRepresentativeDAO.decliningBeneficiaryDetails(beneficiary)) {
			result = true;
		}
		entityTransaction.commit();
		return result;
	}

}
