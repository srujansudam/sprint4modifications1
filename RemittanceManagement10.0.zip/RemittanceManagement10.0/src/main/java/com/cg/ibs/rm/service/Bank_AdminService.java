package com.cg.ibs.rm.service;

import java.math.BigInteger;
import java.util.Set;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.exception.IBSExceptions;

public interface Bank_AdminService {
	public Set<BigInteger> showRequests();

	public Set<CreditCard> showUnapprovedCreditCards(BigInteger uci);

	public Set<Beneficiary> showUnapprovedBeneficiaries(BigInteger uci);

	public boolean saveCreditCardDetails(CreditCard card) throws IBSExceptions;

	public boolean saveBeneficiaryDetails(Beneficiary beneficiary) throws IBSExceptions;

	public boolean disapproveBenficiary(Beneficiary beneficiary) throws IBSExceptions;

	public boolean disapproveCreditCard(CreditCard card) throws IBSExceptions;

}
